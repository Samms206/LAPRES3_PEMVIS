/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul3;

import javax.swing.JOptionPane;

/**
 *
 * @author macbookpro
 */
public class HitungPajak extends javax.swing.JFrame {

    /**
     * Creates new form HitungPajak
     */
    double pajak;
    public HitungPajak() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        eGaji = new javax.swing.JTextField();
        Lpajak = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        eKendaraan = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("DialogInput", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("HITUNG PAJAK");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 450, -1));

        jLabel2.setText("Gaji");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, 20));
        jPanel1.add(eGaji, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 56, 320, 30));

        Lpajak.setText("-");
        jPanel1.add(Lpajak, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 310, 20));

        jButton1.setText("Reset");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 130, -1, -1));

        eKendaraan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tidak Punya", "1", "2", "3" }));
        jPanel1.add(eKendaraan, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 320, 30));

        jLabel4.setText("Kendaraan");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, 20));

        jLabel5.setText("Pajak");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, 20));

        jButton2.setText("Cek Pajak");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 270));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        try {
            int gaji = Integer.parseInt(eGaji.getText());   
            String jumlahkendaraan = eKendaraan.getSelectedItem().toString();
            if (gaji >= 10000000 && "3".equals(jumlahkendaraan)) {
                pajak = gaji * 0.15;
            }else if(gaji >= 5000000 && "3".equals(jumlahkendaraan)){
                pajak = gaji * 0.10;
            }else if(gaji >= 5000000 && "2".equals(jumlahkendaraan)){
                pajak = gaji * 0.10;
            }else if(gaji >= 5000000 && "1".equals(jumlahkendaraan)){
                pajak = gaji * 0.07;
            }else if(gaji < 5000000 && "1".equals(jumlahkendaraan)){
                pajak = gaji * 0.05;
            }else if(gaji < 5000000 && "Tidak Punya".equals(jumlahkendaraan)){
                pajak = gaji * 0.025;
            }
            Lpajak.setText(String.valueOf(pajak));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "masukan hanya angka");
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        eGaji.setText("");
        eKendaraan.setSelectedIndex(0);
        Lpajak.setText("-");
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HitungPajak.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HitungPajak.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HitungPajak.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HitungPajak.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HitungPajak().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Lpajak;
    private javax.swing.JTextField eGaji;
    private javax.swing.JComboBox<String> eKendaraan;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
